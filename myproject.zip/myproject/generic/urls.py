from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import CustomModelViewSet  # Use the CustomModelViewSet

router = DefaultRouter()
router.register(r'custom', CustomModelViewSet)

urlpatterns = [
    path('api/', include(router.urls)),
]

'''
GET /api/generic/ — List all instances.
POST /api/generic/ — Create a new instance.
GET /api/generic/{id}/ — Retrieve a specific instance.
PUT/PATCH /api/generic/{id}/ — Update a specific instance.
DELETE /api/generic/{id}/ — Delete a specific instance.

-------------------------------------------------------------
GET /api/custom/ — List custom model instances.
POST /api/custom/ — Create a new custom model instance.
GET /api/custom/{id}/ — Retrieve a custom model instance.
PUT/PATCH /api/custom/{id}/ — Update a custom model.
DELETE /api/custom/{id}/ — Delete a custom model.
'''