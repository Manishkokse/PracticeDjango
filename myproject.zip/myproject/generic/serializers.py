# generic/serializers.py
from rest_framework import serializers
from .models import GenericModel ,CustomModel

class GenericModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = GenericModel
        fields = ['id', 'created_at', 'updated_at', 'extra']  # Include fields you need for CRUD

# generic/serializers.py
class CustomModelSerializer(GenericModelSerializer):
    class Meta:
        model = CustomModel
        fields = ['id', 'created_at', 'updated_at', 'name', 'description', 'extra']
