# generic/models.py
from django.db import models

class GenericModel(models.Model):
    # Fields for CRUD operations and extra data
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    extra = models.JSONField(default=dict, blank=True, null=True)

    # Optional: Additional fields can be added dynamically in inherited models.

    class Meta:
        abstract = True  # Making this an abstract base class

    def __str__(self):
        return f"GenericModel {self.id}"

# Concrete subclass of GenericModel to be used for CRUD operations
class CustomModel(GenericModel):
    name = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return self.name