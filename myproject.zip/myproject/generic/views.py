# generic/views.py
from rest_framework import viewsets
from .models import CustomModel  # Use the concrete subclass
from .serializers import CustomModelSerializer  # Serializer for CustomModel

class CustomModelViewSet(viewsets.ModelViewSet):
    queryset = CustomModel.objects.all()  # Use the CustomModel for the queryset
    serializer_class = CustomModelSerializer

