import requests
import stripe
from django.conf import settings
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi

stripe.api_key = settings.STRIPE_SECRET_KEY

class CreateCheckoutSessionView(APIView):
    @swagger_auto_schema(
        operation_description="Create a Stripe Checkout session for payment.",
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            required=['product'],
            properties={
                'product': openapi.Schema(
                    type=openapi.TYPE_OBJECT,
                    properties={
                        'name': openapi.Schema(type=openapi.TYPE_STRING, description='Name of the product'),
                        'price': openapi.Schema(type=openapi.TYPE_INTEGER, description='Price of the product in dollars')
                    }
                )
            }
        ),
        responses={200: openapi.Response('Stripe Checkout session created successfully.', 
                                       examples={'application/json': {'session_id': 'string', 'url': 'string'}}),
                   400: 'Bad Request'},
    )
    def post(self, request, *args, **kwargs):
        try:
            product = request.data.get("product")  # Expected to be a dict with price, name, etc.

            checkout_session = stripe.checkout.Session.create(
                payment_method_types=["card"],
                line_items=[
                    {
                        "price_data": {
                            "currency": "usd",
                            "product_data": {"name": product.get("name", "Sample Product")},
                            "unit_amount": int(product.get("price", 1000)) * 100,  # Convert to cents
                        },
                        "quantity": 1,
                    }
                ],
                mode="payment",
                success_url="https://your-site.com/success?session_id={CHECKOUT_SESSION_ID}",
                cancel_url="https://your-site.com/cancel",
            )
            return Response({"session_id": checkout_session.id, "url": checkout_session.url}, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
import stripe
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from django.conf import settings

# Stripe secret key (typically loaded from settings)
stripe.api_key = settings.STRIPE_SECRET_KEY

class StripeWebhookView(APIView):
    @swagger_auto_schema(
        operation_description="Handle Stripe webhook events for payment success.",
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'payload': openapi.Schema(
                    type=openapi.TYPE_STRING,
                    description="Raw payload sent by Stripe in the webhook request body"
                ),
                'sig_header': openapi.Schema(
                    type=openapi.TYPE_STRING,
                    description="The Stripe-Signature header sent by Stripe to verify the authenticity of the webhook event"
                ),
            }
        ),
        responses={
            200: openapi.Response('Webhook event processed successfully.',
                                  examples={'application/json': {'status': 'success'}}),
            400: 'Bad Request - Invalid payload or signature',
        },
    )
    def post(self, request, *args, **kwargs):
        """
        Handle the Stripe webhook events.
        This view verifies the signature, processes the payment event, and handles successful payment.
        """
        payload = request.body
        sig_header = request.headers.get("Stripe-Signature")
        endpoint_secret = "your_webhook_secret"  # Replace with your actual secret
        event = None

        try:
            # Verify and parse the webhook event
            event = stripe.Webhook.construct_event(payload, sig_header, endpoint_secret)
        except ValueError as e:
            return Response({"error": "Invalid payload"}, status=status.HTTP_400_BAD_REQUEST)
        except stripe.error.SignatureVerificationError as e:
            return Response({"error": "Invalid signature"}, status=status.HTTP_400_BAD_REQUEST)

        # Handle the specific event type
        if event["type"] == "checkout.session.completed":
            session = event["data"]["object"]
            print(f"Payment successful for session: {session['id']}")

        return Response({"status": "success"}, status=status.HTTP_200_OK)


class LynnbrookPaymentView(APIView):
    @swagger_auto_schema(
        operation_description="Initiate a payment using Lynnbrook API.",
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            required=['card_number', 'expiration_date', 'cvv', 'amount'],
            properties={
                'card_number': openapi.Schema(type=openapi.TYPE_STRING, description="Card number"),
                'expiration_date': openapi.Schema(type=openapi.TYPE_STRING, description="Expiration date in MM/YY format"),
                'cvv': openapi.Schema(type=openapi.TYPE_STRING, description="Card CVV"),
                'amount': openapi.Schema(type=openapi.TYPE_INTEGER, description="Amount to charge in USD")
            }
        ),
        responses={200: openapi.Response('Payment processed successfully.',
                                        examples={'application/json': {'status': 'success', 'transaction_id': 'string'}}),
                   400: 'Bad Request'},
    )
    def post(self, request, *args, **kwargs):
        """
        Initiates a payment using Lynnbrook.
        """
        try:
            data = request.data
            card_number = data.get("card_number")
            expiration_date = data.get("expiration_date")
            cvv = data.get("cvv")
            amount = data.get("amount")

            if not all([card_number, expiration_date, cvv, amount]):
                return Response({"error": "Missing required payment details"}, status=status.HTTP_400_BAD_REQUEST)

            payload = {
                "merchant_id": settings.LYNNBROOK_MERCHANT_ID,
                "amount": amount,
                "card_number": card_number,
                "expiration_date": expiration_date,
                "cvv": cvv,
                "currency": "USD",
                "description": "Payment for order"
            }

            headers = {
                "Authorization": f"Bearer {settings.LYNNBROOK_API_KEY}",
                "Content-Type": "application/json"
            }

            response = requests.post(f"{settings.LYNNBROOK_BASE_URL}/payments", json=payload, headers=headers)

            if response.status_code == 200:
                return Response(response.json(), status=status.HTTP_200_OK)
            else:
                return Response({"error": response.text}, status=response.status_code)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class LynnbrookWebhookView(APIView):
    @swagger_auto_schema(
        operation_description="Webhook to capture Lynnbrook payment success events.",
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'status': openapi.Schema(type=openapi.TYPE_STRING, description="Status of the transaction"),
                'transaction_id': openapi.Schema(type=openapi.TYPE_STRING, description="Transaction ID for the payment"),
            }
        ),
        responses={
            200: openapi.Response('Webhook event received successfully.',
                                  examples={'application/json': {'status': 'received'}}),
            400: 'Bad Request - Invalid webhook payload',
        },
    )
    def post(self, request, *args, **kwargs):
        """
        Webhook to capture Lynnbrook payment success events.
        """
        try:
            event = request.data  # Lynnbrook sends a JSON payload

            if event.get("status") == "successful":
                print(f"Payment successful for transaction ID: {event.get('transaction_id')}")

            return Response({"status": "received"}, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
