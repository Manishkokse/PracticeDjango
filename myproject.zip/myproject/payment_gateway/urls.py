from django.urls import path
from .views import CreateCheckoutSessionView, StripeWebhookView,LynnbrookPaymentView, LynnbrookWebhookView
 
urlpatterns = [
    path("create-checkout-session/", CreateCheckoutSessionView.as_view(), name="create-checkout-session"),
    path("stripe-webhook/", StripeWebhookView.as_view(), name="stripe-webhook"),
    path("lynnbrook-payment/", LynnbrookPaymentView.as_view(), name="lynnbrook-payment"),
    path("lynnbrook-webhook/", LynnbrookWebhookView.as_view(), name="lynnbrook-webhook"),
]
